document.getElementById('dreamForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const title = document.getElementById('dreamTitle').value;
  const content = document.getElementById('dreamContent').value;

  const dream = {
    title,
    content,
    date: new Date().toLocaleString()
  };

  const dreams = JSON.parse(localStorage.getItem('dreams') || '[]');
  dreams.unshift(dream);
  localStorage.setItem('dreams', JSON.stringify(dreams));

  displayDreams();
  this.reset();
});

function displayDreams() {
  const dreams = JSON.parse(localStorage.getItem('dreams') || '[]');
  const list = document.getElementById('dreamList');
  list.innerHTML = '';

  dreams.forEach((dream, index) => {
    const div = document.createElement('div');
    div.innerHTML = \`<h3>\${dream.title}</h3><p>\${dream.content}</p><small>\${dream.date}</small><hr />\`;
    list.appendChild(div);
  });
}

window.onload = displayDreams;
